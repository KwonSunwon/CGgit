#pragma once
#include "stdafx.h"

vector<int> _makeMaze(int row, int col);